  /******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  * (c) EE2028 Teaching Team
  * Joshua Goh Min Rui
  ******************************************************************************/
/*We have decided to join the Agents... Muah HAHAHA*/

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_accelero.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_tsensor.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_psensor.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_hsensor.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_gyro.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_magneto.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "math.h"

/* Function Declarations---------------------------------------------------------*/
static void MX_GPIO_Init(void);
static void UART1_Init(void);
static void Mode(void);
static void Buttons(void);
static void SENTRY_MODE(void);
static void BATTLE_MODE(void);
static void BATTLE_MODE_WARNING(void);
static void Exception(float Gyro, float Mag, float Pre, float Hum, float Temp, float Acc);
void acc_interrupt_config(void);
void gyro_interrupt_config(void);
void tilt_interrupt_config(void);
static float Gyroscope(void);
static float Magnetometer(void);
static float Pressure(void);
static float Humidity(void);
static float Temperature(void);
static float Accelerometer(void);
extern void initialise_monitor_handles(void);	// for semi-hosting support (printf)

UART_HandleTypeDef huart1;

/*Macro Definition for ease of reading---------------------------------------------*/
/*Modes definition*/
#define sentry 0
#define battle 1
#define warning 2

/*Threshold definition*/
#define GYRO_THRESHOLD 400.0
#define MAGNETO_THRESHOLD 1.20
#define PRESSURE_THRESHOLD_LOW 70.0
#define PRESSURE_THRESHOLD_HIGH 110.0
#define HUMIDITY_THRESHOLD 50.0
#define ACCEL_THRESHOLD_LOW -20.0
#define ACCEL_THRESHOLD_HIGH 20.0
#define TEMP_THRESHOLD_LOW -20.0
#define TEMP_THRESHOLD_HIGH 80.0



/*Global Variables---------------------------------------------------------*/
int mode = sentry;
int press = 0;
int tflag=0;

/*Variables for Teleport Charging*/
int charge= 3;
uint32_t time_enemy_detected;

/*Timing intervals for each mode*/
uint32_t current;
uint32_t time_sentry = 0;
uint32_t time_battle = 0;
uint32_t time_battle_warning = 0;
uint32_t time_battle_LED = 0;


/*Array Buffer for UART1*/
char message_print[32];
char long_message_print[128];

/*Time instance used for button deboucing*/
uint32_t t1,t2;

/*Flags raised for when sensor reads value that exceeds threshold*/
int Gflag,Mflag,Pflag_H,Pflag_L,Hflag,Tflag_H,Tflag_L,Aflag_H,Aflag_L =0;
int accuracy;
volatile short int accflag=0;
volatile short int gyroflag = 0;
volatile short int tiltflag = 0;

//External interrupt function
HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{

  if((GPIO_Pin == BUTTON_EXTI13_Pin) && (tflag==0)){
	  tflag++;
	  t1 = uwTick;
  }
  else if((GPIO_Pin == BUTTON_EXTI13_Pin) && (tflag>0)){
	  tflag++;
	  t2 = uwTick;
  }

  if (GPIO_Pin == LSM6DSL_INT1_EXTI11_Pin){
	  //accelerometer
	  uint8_t tmp;
	  tmp = SENSOR_IO_Read(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW+1, LSM6DSL_ACC_GYRO_WAKE_UP_SRC);
	  tmp &= 0x20; //read bit[5] to determine if FF flag was raised by device
	  if (tmp){
	  	accflag = 1;
	  }

//	  uint8_t tmp1;
//	  tmp1 = SENSOR_IO_Read(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW+1, LSM6DSL_ACC_GYRO_WAKE_UP_SRC);
////	  tmp1 = SENSOR_IO_Read(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW+1, LSM6DSL_ACC_GYRO_TAP_SRC);
//	  tmp1 &= 0x01;
////	  tmp1 &= 0x08;
//	  if(tmp1){
//		  if(gyroflag==0){
//			  gyroflag=1;
//		  }
//		  else{
//			  gyroflag=0;
//		  }
//	  }

	  uint8_t tmp2;
	  tmp2 = SENSOR_IO_Read(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW+1, LSM6DSL_ACC_GYRO_FUNC_SRC);
	  tmp2 &= 0x20;
	  if(tmp2){
		  if(mode==battle||mode==warning){
		  tiltflag = 1;
		  }
	  }
	  else{
		  tiltflag=0;
	  }

	  }

}


//main function that loops forever
int main(void)
{
	initialise_monitor_handles(); // for semi-hosting support (printf)

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();
	MX_GPIO_Init();
	UART1_Init();

	/* Peripheral initializations using BSP functions */
	BSP_ACCELERO_Init();
	BSP_TSENSOR_Init();
	BSP_PSENSOR_Init();
	BSP_HSENSOR_Init();
	BSP_GYRO_Init();
	BSP_MAGNETO_Init();

	/*Buzzer (additional output) initialization*/
	acc_interrupt_config();
//	gyro_interrupt_config();
	tilt_interrupt_config();
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);

	while (1)
	{
		 /*Function to switch between modes based on button press*/
		 Mode();
	}

	return 0;
}

static void Mode(void){
	if(mode==sentry){
		SENTRY_MODE();
	}

	if(mode==battle){
		BATTLE_MODE();
	}

	if(mode==warning){
		sprintf(message_print, "Enemy Detected!\r\n");
		HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
		time_enemy_detected = uwTick;

		BATTLE_MODE_WARNING();
	}


}

static void Buttons(void){
	/*Detects single/double press for button within a 0.5 seconds interval*/

	/*Detects single press*/
	if((tflag==1) && (uwTick - t1 > 500)){
		tflag=0;
		press=1;
	}
	/*Detects double press*/
	if((tflag==2) && (t2-t1<500)){
		press = 2;
		tflag = 0;
	}

}

/*Function for printing exceeded thresholds*/
static void Exception(float Gyro, float Mag, float Pre, float Hum, float Temp, float Acc){
	if (Gflag==1){
		sprintf(long_message_print,"G: %0.2f dps, exceeds threshold of %0.2f dps. \r\n",Gyro, GYRO_THRESHOLD);
		HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
	}
	if(Mflag==1){
		sprintf(long_message_print,"M:%0.2f gauss, exceeds threshold of %0.2f gauss. \r\n",Mag,MAGNETO_THRESHOLD);
		HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
	}
	if(Pflag_H==1){
		sprintf(long_message_print,"P:%0.2f kPa, exceeds threshold of %0.2f kPa. \r\n",Pre,PRESSURE_THRESHOLD_HIGH);
		HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
	}
	if(Pflag_L==1){
		sprintf(long_message_print,"P:%0.2f kPa, exceeds threshold of %0.2f kPa. \r\n",Pre,PRESSURE_THRESHOLD_LOW);
		HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
	}
	if(Hflag==1){
		sprintf(long_message_print,"H:%0.2f %%, exceeds threshold of %0.2f %%. \r\n",Hum,HUMIDITY_THRESHOLD);
		HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
	}
	if(Tflag_H==1){
		sprintf(long_message_print,"T: %0.2f deg cel, exceeds threshold of %0.2f deg cel. \r\n",Temp,TEMP_THRESHOLD_HIGH);
		HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
	}
	if(Tflag_L==1){
		sprintf(long_message_print,"T: %0.2f deg cel, exceeds threshold of %0.2f deg cel. \r\n",Temp,TEMP_THRESHOLD_LOW);
		HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
	}
	if(Aflag_H==1){
		sprintf(long_message_print,"A: %0.2f M s^-2, exceeds threshold of %0.2f M s^-2. \r\n",Acc,ACCEL_THRESHOLD_HIGH);
		HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
	}
	if(Aflag_L==1){
		sprintf(long_message_print,"A: %0.2f M s^-2, exceeds threshold of %0.2f M s^-2. \r\n",Acc,ACCEL_THRESHOLD_LOW);
		HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
	}

}

/*Function for Sentry Mode*/
static void SENTRY_MODE(void)
{
	mode = sentry;
	HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_14);
	/*Start up stage: Enters Sentry Mode*/
	sprintf(message_print, "Entering SENTRY_MODE\r\n");
	HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);

	while(1){
		Buttons();
		if(press==2){
			mode = battle;
			press=0;
			break;
		}
		uint32_t current = uwTick;
		if(current-time_sentry>1000){
			float Gyro = Gyroscope();
			float Mag = Magnetometer();
			float Pre = Pressure();
			float Hum = Humidity();
			if(Gflag||Mflag||Pflag_H||Pflag_L||Hflag==1){
				Exception(Gyro, Mag, Pre, Hum,0,0);
			}
			else{
			sprintf(long_message_print,"G:%0.2f dps, M:%0.2f gauss, P:%0.2f kPa, H:%0.2f %% \r\n",Gyro,Mag,Pre,Hum);
			HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
			}
			time_sentry = HAL_GetTick();

			if(accflag==1){
				mode = battle;
			}
			else{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
			}

//			if(gyroflag==1){
//				sprintf(message_print, "Teleport Field Charging...\r\n");
//				HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
//				if(charge<10){
//					charge+=1;
//				}
//				if(charge>=10){
//					sprintf(message_print, "Teleport Field Full Charge...\r\n");
//					HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
//					gyroflag=0;
//				}
//			}
		}
	}
}

/*Function for Battle Mode*/
static void BATTLE_MODE(void){
	mode = battle;
	sprintf(message_print, "Entering BATTLE mode\r\n");
	HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);

	while(1){
		Buttons();
		if(press==1){
			mode = warning;
			press=0;
			break;
		}
		else if(press==2){
			mode= sentry;
			press=0;
			break;
		}
		uint32_t current = uwTick;
		if(current-time_battle>=1000){
			HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_14);

			if(accflag==1){
				sprintf(message_print, "Danger! Free Fall Detected\r\n");
				HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);
				mode=battle;
				accflag=0;
			}
			else{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
			}

			float Gyro = Gyroscope();
			float Mag = Magnetometer();
			float Pre = Pressure();
			float Hum = Humidity();
			float Temp = Temperature();
			float Acc = Accelerometer();
			if(Gflag||Mflag||Pflag_H||Pflag_L||Hflag||Tflag_H||Tflag_L||Aflag_H||Aflag_L ==1){
				Exception(Gyro, Mag, Pre, Hum, Temp,Acc);
			}
			else{
			sprintf(long_message_print,"T: %0.2f deg cel, P:%0.2f kPa, H:%0.2f %%, A:%0.2f M s^-2, G:%0.2f dps, M:%0.2f gauss\r\n", Temp, Pre,Hum,Acc,Gyro,Mag);
			HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
			}
			time_battle = HAL_GetTick();

			if(tiltflag==1){
				sprintf(long_message_print, "Ship Tilted more than 35 degrees! WARNING!\r\n");
				HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
				tiltflag=0;
			}
		}
	}

}

/*Function for Battle Mode Warning*/
static void BATTLE_MODE_WARNING(void){
	mode = warning;

	while(1){
		Buttons();
		uint32_t current = uwTick;
		if(current-time_battle_LED>333.3333333333333333){
			HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_14);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);
			time_battle_LED = HAL_GetTick();
		}
		if(current - time_battle_warning >1000){
			sprintf(message_print, "WARNING!\r\n");
			HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
			time_battle_warning = HAL_GetTick();

			if(tiltflag==1){
				sprintf(long_message_print, "Ship Tilted more than 35 degrees! Teleporter Accuracy decreased\r\n");
				HAL_UART_Transmit(&huart1, (uint8_t*)long_message_print, strlen(long_message_print),0xFFFF);
				tiltflag=0;
			}
		}

		if(press==1){
			if(charge<10){
				charge +=3;
				press=0;
			}
			if(charge >=5){
				charge -=5;
				//If warship is tilted and constantly changing orientation, accuracy of teleporter is decreased with rand function
				if(tiltflag==1){
					accuracy = rand() % 2;
				if(accuracy==1){
				sprintf(message_print, "Enemy Captured!\r\n");
				HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
				}
				if(accuracy==0){
					sprintf(message_print, "Enemy Lost due to tilt!\r\n");
					HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
				}
				}
				else{
				sprintf(message_print, "Enemy Captured!\r\n");
				HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
				}
				press=0;
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
				mode=battle;
				break;
			}
		}

		/*5 second*/
		if(uwTick-time_enemy_detected>5000){
			press=0;
			sprintf(message_print, "Enemy Lost!\r\n");
			HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
			mode=battle;
			break;
		}
	}
}

//Function for Gyroscope Sensor
static float Gyroscope(void){
	float gyro_data[3];
	float rms_gyro_data;
	int16_t gyro_data_i16[3] = { 0 };
	BSP_GYRO_GetXYZ(gyro_data_i16);
	//Converting Gyroscope data in terms of dps
	gyro_data[0] = (float)gyro_data_i16[0]/1000.0f;
	gyro_data[1] = (float)gyro_data_i16[1]/1000.0f;
	gyro_data[2] = (float)gyro_data_i16[2]/1000.0f;
	//Finding RMS value of gyroscope based on rotation angles x,y and z.
	rms_gyro_data = (sqrt((gyro_data[0]*gyro_data[0])+(gyro_data[1]*gyro_data[1])+(gyro_data[2]*gyro_data[2])));
	if(rms_gyro_data>GYRO_THRESHOLD){
		Gflag = 1;
	}
	else{
		Gflag=0;
	}
	return rms_gyro_data;
}

//Function for Magnetometer Sensor
static float Magnetometer(void){
	float mag_data[3];
	float rms_mag_data;
	int16_t mag_data_i16[3] = { 0 };
	BSP_MAGNETO_GetXYZ(mag_data_i16);
	//Converting Magnetometer in terms of gauss
	mag_data[0] = (float)mag_data_i16[0]/10000.0f;
	mag_data[1] = (float)mag_data_i16[1]/10000.0f;
	mag_data[2] = (float)mag_data_i16[2]/10000.0f;
	//Finding RMS value of magnetometer data
	rms_mag_data = (sqrt((mag_data[0]*mag_data[0])+(mag_data[1]*mag_data[1])+(mag_data[2]*mag_data[2])));
	if(rms_mag_data>MAGNETO_THRESHOLD){
		Mflag = 1;
	}
	else{
		Mflag = 0;
	}
	return rms_mag_data;
}

//Function for Pressure Sensor
static float Pressure(void){
	float pressure_data;
	//Read Pressure in terms of kiloPascals
	pressure_data = BSP_PSENSOR_ReadPressure()/10.0f;
	if(pressure_data>=PRESSURE_THRESHOLD_HIGH){
		Pflag_H = 1;
	}
	else if(pressure_data<=PRESSURE_THRESHOLD_LOW){
		Pflag_L = 1;
	}
	else{
		Pflag_H = 0;
		Pflag_L = 0;
	}
	return pressure_data;
}

//Function for Humidity Sensor
static float Humidity(void){
	float hum_data;
	hum_data = BSP_HSENSOR_ReadHumidity();

	if(hum_data<=HUMIDITY_THRESHOLD){
		Hflag = 1;
	}
	else{
		Hflag = 0;
	}
	return hum_data;
}

//Function for Temperature Sensor
static float Temperature(void){
	float temp_data;
	temp_data = BSP_TSENSOR_ReadTemp();
	if(temp_data>=TEMP_THRESHOLD_HIGH){
		Tflag_H = 1;
	}
	else if(temp_data<=TEMP_THRESHOLD_LOW){
		Tflag_L=1;
	}
	else{
		Tflag_H = 0;
		Tflag_L = 0;
	}
	return temp_data;
}


//Function for Accelerometer Sensor
static float Accelerometer(void){
	float accel_data[3];
	int16_t accel_data_i16[3] = { 0 };      // array to store the x, y and z readings.
	BSP_ACCELERO_AccGetXYZ(accel_data_i16);    // read accelerometer
	// the function above returns 16 bit integers which are 100 * acceleration_in_m/s2. Converting to float to print the actual acceleration.
	accel_data[0] = (float)accel_data_i16[0] / 100.0f;
	accel_data[1] = (float)accel_data_i16[1] / 100.0f;
	accel_data[2] = (float)accel_data_i16[2] / 100.0f;
	float z_axis = accel_data[2];
	if(z_axis>=ACCEL_THRESHOLD_HIGH){
		Aflag_H = 1;
	}
	else if (z_axis<=ACCEL_THRESHOLD_LOW){
		Aflag_L = 1;
	}
	else{
		Aflag_H = 0;
		Aflag_L = 0;
	}
	return z_axis;
}

/*Free Fall Interupt Configuration*/
void acc_interrupt_config(void)
{
	//1000 0000 set bit[7] to enable interrupts
	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_TAP_CFG1, 0x80);
	//0000 1000 FF_Dur [4:0] = 00001 & FF_Ths [2:0] = 000
	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_FREE_FALL, 0x08);
	//0001 0000 Enables bit 4 of MD1_CFG Register
	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_MD1_CFG, 0x10);
}

/*Double Tap Interupt Configuration*/
//void gyro_interrupt_config(void)
//{
//	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_CTRL1_XL, 0x60);
//	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_TAP_CFG1, 0x8E);
//	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_TAP_THS_6D , 0x8C);
//	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_INT_DUR2, 0x7F);
//	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_WAKE_UP_THS , 0x80);
//	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_MD2_CFG, 0x08);
//}

void tilt_interrupt_config(void){
	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_CTRL10_C , 0x0C);
	SENSOR_IO_Write(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_MD1_CFG, 0x02);

}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  /*Configure GPIO pin Output Level */

  HAL_GPIO_WritePin(GPIOB, LED2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3 , GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4 , GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4 , GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1 , GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7 , GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2 , GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15 , GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2 , GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOD, LSM6DSL_INT1_EXTI11_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin LED2_Pin */
  GPIO_InitStruct.Pin = LED2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  // Configuration of BUTTON_EXTI13_Pin (G{IO-C Pin-13)as AF
  GPIO_InitStruct.Pin = BUTTON_EXTI13_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  // Configuration of LSM6DSL EXTI 11
  GPIO_InitStruct.Pin = LSM6DSL_INT1_EXTI11_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  //Configuration of D8 as output for Buzzer
  GPIO_InitStruct.Pin = ARD_D8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  // Enable NVIC EXTI line 13
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
  HAL_NVIC_EnableIRQ(SysTick_IRQn);
  HAL_NVIC_SetPriority(SysTick_IRQn, 1, 1);
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0x0F, 0);

}



static void UART1_Init(void)
{
/* Pin configuration for UART. BSP_COM_Init() can do this automatically */
__HAL_RCC_GPIOB_CLK_ENABLE();
GPIO_InitTypeDef GPIO_InitStruct = {0};
GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
GPIO_InitStruct.Pin = GPIO_PIN_7|GPIO_PIN_6;
GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
GPIO_InitStruct.Pull = GPIO_NOPULL;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* Configuring UART1 */
huart1.Instance = USART1;
huart1.Init.BaudRate = 115200;
huart1.Init.WordLength = UART_WORDLENGTH_8B;
huart1.Init.StopBits = UART_STOPBITS_1;
huart1.Init.Parity = UART_PARITY_NONE;
huart1.Init.Mode = UART_MODE_TX_RX;
huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
huart1.Init.OverSampling = UART_OVERSAMPLING_16;
huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
if (HAL_UART_Init(&huart1) != HAL_OK)
{
while(1);
}

}


